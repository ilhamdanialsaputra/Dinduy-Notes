# Dinduy (Kotlin + Jetpack Compose)

Build lewat GitHub Actions: push ke `main`, lalu ambil APK di tab Actions, artifact `Dinduy-apk`.

Opsional (supaya APK bisa di-update tanpa uninstall): isi GitHub Secrets
`KEYSTORE_B64` (keystore di-base64), `KS_PASS`, `KS_ALIAS`, `KEY_PASS`.
Tanpa secrets, APK ditandatangani kunci debug yang berubah tiap build.

Pindah dari versi web: di versi web buka Pengaturan, Cadangan, Simpan cadangan.
Di versi native buka Pengaturan, Cadangan, Pulihkan cadangan, pilih berkas .dinduy itu.
